"""Render Figures 1-3 for the IJDRR article (matplotlib, static, 300 dpi PNG + vector PDF)."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.lines import Line2D

D = '/home/claude/figures/data'; OUT = '/home/claude/figures/out'
import os; os.makedirs(OUT, exist_ok=True)

# palette (validated): categorical slots in fixed order; ordinal blue steps; ink tokens
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET = '#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#4a3aa7'
BLUE_LIGHT, BLUE_DARK = '#86b6ef', '#1c5cab'
INK, INK2, MUTED, GRID, AXIS, SURF = '#0b0b0b', '#52514e', '#898781', '#e1e0d9', '#c3c2b7', '#ffffff'

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8, 'axes.edgecolor': AXIS, 'axes.linewidth': 0.8,
                     'xtick.color': MUTED, 'ytick.color': MUTED, 'axes.labelcolor': INK2, 'text.color': INK,
                     'axes.titlesize': 9, 'axes.titleweight': 'semibold', 'legend.fontsize': 7.5, 'figure.facecolor': SURF, 'axes.facecolor': SURF,
                     'pdf.fonttype': 42, 'ps.fonttype': 42})

def clean_axes(ax, left=True, bottom=True):
    for s in ['top', 'right']: ax.spines[s].set_visible(False)
    ax.spines['left'].set_visible(left); ax.spines['bottom'].set_visible(bottom)
    ax.tick_params(length=0)

def hbar_rounded(ax, y, width, height, color, r=None):
    """horizontal bar: square at the baseline (x=0), rounded data end"""
    if width <= 0: return
    r = r or height * 0.45
    r = min(r, width / 2)
    ax.add_patch(FancyBboxPatch((0, y - height / 2), width, height, boxstyle=f'round,pad=0,rounding_size={r}', linewidth=0, facecolor=color, mutation_aspect=1))
    ax.add_patch(Rectangle((0, y - height / 2), min(r, width), height, linewidth=0, facecolor=color))  # square the baseline end

# =============================== FIGURE 1 ===============================
f1 = pd.read_csv(f'{D}/fig1_subtel2024_channel_use.csv')
acts = ['WhatsApp chat', 'Social networks', 'Read news online']; cols = {'WhatsApp chat': BLUE, 'Social networks': ORANGE, 'Read news online': AQUA}
fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.6), gridspec_kw={'width_ratios': [1, 1.35]})
def panel(ax, dim, order, title):
    sub = f1[f1.dimension == dim]
    nat = f1[f1.dimension == 'national'].set_index('activity')['pct']
    ng = len(order); bh = 0.24; gap = 0.03
    for gi, g in enumerate(order):
        for ai, a in enumerate(acts):
            v = float(sub[(sub.group == g) & (sub.activity == a)]['pct'].iloc[0])
            y = gi + (ai - 1) * (bh + gap)
            hbar_rounded(ax, y, v, bh, cols[a])
            ax.text(v + 1.2, y, f'{v:.0f}', va='center', ha='left', fontsize=6.5, color=INK2)
    for ai, a in enumerate(acts):  # national reference tick per series
        ax.axvline(nat[a], color=cols[a], lw=0.8, ls=(0, (2, 2)), alpha=0.55, zorder=0)
    ax.set_yticks(range(ng)); ax.set_yticklabels(order, color=INK); ax.invert_yaxis()
    ax.set_xlim(0, 100); ax.set_xticks([0, 25, 50, 75, 100]); ax.set_xticklabels(['0', '25', '50', '75', '100%'])
    ax.set_title(title, loc='left', color=INK); clean_axes(ax, left=False)
    ax.set_ylim(ng - 0.5, -0.6)
panel(axes[0], 'age', ['16-29', '30-44', '45-59', '60+'], 'A. By age group')
panel(axes[1], 'region', ['Arica y Parinacota', 'Tarapacá', 'Antofagasta', 'Atacama', 'Coquimbo', 'Valparaíso', 'Metropolitana'], 'B. By region (north, Valparaíso, capital)')
handles = [Line2D([0], [0], color=cols[a], lw=6, solid_capstyle='round') for a in acts] + [Line2D([0], [0], color=MUTED, lw=0.8, ls=(0, (2, 2)))]
fig.legend(handles, acts + ['National average (dashed, per activity)'], loc='lower center', ncol=4, frameon=False, bbox_to_anchor=(0.5, -0.02))
fig.suptitle('Internet activities in the last three months, Chile 2024 (% of persons aged 16+)', x=0.01, ha='left', fontsize=9.5, fontweight='semibold', color=INK)
fig.text(0.01, -0.09, 'Source: Subtel, XI Encuesta de Acceso, Usos y Usuarios de Internet 2024 (n = 4,418 persons; person weights). Regional n: 100–540.', fontsize=6.5, color=MUTED)
fig.tight_layout(rect=(0, 0.06, 1, 0.95))
fig.savefig(f'{OUT}/Figure1_channel_use_2024.png', dpi=300, bbox_inches='tight'); fig.savefig(f'{OUT}/Figure1_channel_use_2024.pdf', bbox_inches='tight'); plt.close(fig)

# =============================== FIGURE 2 ===============================
f2 = pd.read_csv(f'{D}/fig2_elsoc_trust_2016_2022.csv')
fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.4), sharey=True)
def bands(ax, ylab):
    ax.axvspan(2019.75, 2019.95, color=GRID, alpha=0.9, lw=0, zorder=0)   # 18-O
    ax.axvspan(2020.2, 2021.6, color=GRID, alpha=0.55, lw=0, zorder=0)   # pandemic
    ax.text(2019.68, ylab, '18-O', ha='right', va='top', fontsize=6.5, color=INK2)
    ax.text(2020.27, ylab, 'COVID-19', ha='left', va='top', fontsize=6.5, color=INK2)
def lines(ax, items, colors, title, ylab):
    for it, c in zip(items, colors):
        s = f2[f2.item == it].sort_values('year')
        ax.plot(s.year, s.pct_high, color=c, lw=2, solid_joinstyle='round', solid_capstyle='round', zorder=3)
        ax.scatter(s.year, s.pct_high, s=34, color=c, edgecolor=SURF, linewidth=1.5, zorder=4)
        ax.text(s.year.iloc[-1] + 0.12, s.pct_high.iloc[-1], f'{it}  {s.pct_high.iloc[-1]:.0f}%', va='center', ha='left', fontsize=7, color=INK2)
    bands(ax, ylab); ax.set_xlim(2015.7, 2024.2); ax.set_xticks([2016, 2017, 2018, 2019, 2021, 2022]); ax.set_ylim(0, 100)
    ax.set_yticks([0, 25, 50, 75, 100]); ax.set_yticklabels(['0', '25', '50', '75', '100%'])
    ax.grid(axis='y', color=GRID, lw=0.8); ax.set_axisbelow(True); clean_axes(ax); ax.set_title(title, loc='left', color=INK)
lines(axes[0], ['Carabineros', 'Government', 'Congress'], [BLUE, ORANGE, AQUA], 'A. Asked in every wave', 97)
lines(axes[1], ['Bomberos', 'Armed Forces', 'Municipality', 'Traditional media'], [YELLOW, MAGENTA, GREEN, VIOLET], 'B. Asked from 2019', 72)
ents = [('Carabineros', BLUE), ('Government', ORANGE), ('Congress', AQUA), ('Bomberos', YELLOW), ('Armed Forces', MAGENTA), ('Municipality', GREEN), ('Traditional media', VIOLET)]
h1 = [Line2D([0], [0], color=c, lw=2, marker='o', markersize=5, markeredgecolor=SURF) for _, c in ents]
fig.legend(h1, [n for n, _ in ents], loc='lower center', ncol=7, frameon=False, bbox_to_anchor=(0.5, -0.03), handlelength=1.6, columnspacing=1.1)
fig.suptitle('Trust in institutions, Chile 2016–2022: % answering "bastante" or "mucha confianza"', x=0.01, ha='left', fontsize=9.5, fontweight='semibold', color=INK)
fig.text(0.01, -0.10, 'Source: ELSOC 2016–2022 (COES), cross-sectional weights; no 2020 wave. n per point 2,450–3,740 (2021 President, 2022 Bomberos/media/municipality ≈ 1,500–1,750). Bands mark the October 2019 uprising and the pandemic.', fontsize=6.5, color=MUTED)
fig.tight_layout(rect=(0, 0.06, 1, 0.94))
fig.savefig(f'{OUT}/Figure2_trust_2016_2022.png', dpi=300, bbox_inches='tight'); fig.savefig(f'{OUT}/Figure2_trust_2016_2022.pdf', bbox_inches='tight'); plt.close(fig)

# =============================== FIGURE 3 ===============================
f3 = pd.read_csv(f'{D}/fig3_platforms_news_2017_2023.csv', keep_default_na=False)
f3['platform'] = f3['platform'].replace({'None': 'None of these'})
p = f3.pivot(index='platform', columns='year', values='pct')
order = ['Facebook', 'Instagram', 'YouTube', 'Twitter/X', 'WhatsApp', 'TikTok', 'None of these']
p = p.reindex(order)
fig, ax = plt.subplots(figsize=(4.6, 3.3))
for i, plat in enumerate(order):
    a, b = p.loc[plat, 2017], p.loc[plat, 2023]
    if pd.notna(a) and pd.notna(b):
        ax.plot([a, b], [i, i], color=GRID, lw=2.5, zorder=1, solid_capstyle='round')
    if pd.notna(a):
        ax.scatter(a, i, s=48, color=BLUE_LIGHT, edgecolor=SURF, linewidth=1.5, zorder=3); ax.text(a, i - 0.32, f'{a:.0f}', ha='center', va='bottom', fontsize=6.5, color=INK2)
    if pd.notna(b):
        ax.scatter(b, i, s=48, color=BLUE_DARK, edgecolor=SURF, linewidth=1.5, zorder=3); ax.text(b, i + 0.32, f'{b:.0f}', ha='center', va='top', fontsize=6.5, color=INK2)
ax.set_yticks(range(len(order))); ax.set_yticklabels(order, color=INK); ax.invert_yaxis(); ax.set_ylim(len(order) - 0.4, -0.7)
ax.set_xlim(0, 45); ax.set_xticks([0, 10, 20, 30, 40]); ax.set_xticklabels(['0', '10', '20', '30', '40%'])
ax.grid(axis='x', color=GRID, lw=0.8); ax.set_axisbelow(True); clean_axes(ax, left=False)
ax.legend(handles=[Line2D([0], [0], marker='o', color='none', markerfacecolor=BLUE_LIGHT, markeredgecolor=SURF, markersize=7), Line2D([0], [0], marker='o', color='none', markerfacecolor=BLUE_DARK, markeredgecolor=SURF, markersize=7)],
          labels=['2017', '2023'], loc='lower right', frameon=False)
ax.set_title('Social networks used "to inform yourself about current affairs", Chile', loc='left', color=INK, fontsize=9)
fig.text(0.01, -0.06, 'Source: Subtel, IX (2017, n = 3,033) and X (2023, n = 4,696) Encuesta de Acceso y Uso de Internet, module S3.3; person weights. 2017 also listed Google (63%), omitted; "None" bases differ between waves.', fontsize=6.3, color=MUTED, wrap=True)
fig.tight_layout()
fig.savefig(f'{OUT}/Figure3_platforms_news_2017_2023.png', dpi=300, bbox_inches='tight'); fig.savefig(f'{OUT}/Figure3_platforms_news_2017_2023.pdf', bbox_inches='tight'); plt.close(fig)
print('done', os.listdir(OUT))
