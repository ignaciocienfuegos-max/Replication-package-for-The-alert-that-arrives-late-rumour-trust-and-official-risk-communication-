"""Prepare the data behind Figures 1-3 and Table 1 (weighted estimates with n)."""
import pyreadstat, pandas as pd, numpy as np, os, json
os.makedirs('/home/claude/figures/data', exist_ok=True)
OUT = '/home/claude/figures/data'

def wshare(flag, w):
    """weighted % of flag==1 among non-missing"""
    m = flag.notna() & w.notna()
    return float(w[m & (flag == 1)].sum() / w[m].sum() * 100), int(m.sum())

# ---------------- Subtel 2024: channel use by age and region ----------------
df, meta = pyreadstat.read_sav('/home/claude/data/subtel/BBDD_Subtel2024_03022025.sav__x/BBDD_Subtel2024_03022025.sav')
w = df['PON_PER_SIN_GSE']
acts = {'Q21_12': 'WhatsApp chat', 'Q21_11': 'Social networks', 'Q21_20': 'Read news online', 'Q21_7': 'Government/organisation information'}
age = pd.cut(df['Q1_1'], [15, 29, 44, 59, 120], labels=['16-29', '30-44', '45-59', '60+'])
rows = []
for v, name in acts.items():
    p, n = wshare(df[v], w); rows.append({'dimension': 'national', 'group': 'National', 'activity': name, 'pct': round(p, 1), 'n': n})
    for g in age.cat.categories:
        m = age == g; p, n = wshare(df.loc[m, v], w[m]); rows.append({'dimension': 'age', 'group': g, 'activity': name, 'pct': round(p, 1), 'n': n})
    regs = {15: 'Arica y Parinacota', 1: 'Tarapacá', 2: 'Antofagasta', 3: 'Atacama', 4: 'Coquimbo', 5: 'Valparaíso', 13: 'Metropolitana'}
    for code, rname in regs.items():
        m = df['COD_REGION'] == code; p, n = wshare(df.loc[m, v], w[m]); rows.append({'dimension': 'region', 'group': rname, 'activity': name, 'pct': round(p, 1), 'n': n})
    for code, g in {1: 'C1', 2: 'C2', 3: 'C3', 4: 'D', 5: 'E'}.items():
        m = df['GSEV1'] == code
        if m.sum() > 0:
            p, n = wshare(df.loc[m, v], w[m]); rows.append({'dimension': 'gse', 'group': g, 'activity': name, 'pct': round(p, 1), 'n': n})
sub24 = pd.DataFrame(rows); sub24.to_csv(f'{OUT}/fig1_subtel2024_channel_use.csv', index=False)
print(sub24[sub24.dimension == 'national'])

# ---------------- Subtel 2017 vs 2023: platforms used to inform about current affairs ----------------
d17, m17 = pyreadstat.read_sav('/home/claude/data/subtel/BBDD_IX_Encuesta_VFINAL_PUB.sav'); w17 = d17['FACTOR_PERSONA']
plat17 = {1: 'Facebook', 2: 'Twitter/X', 3: 'Instagram', 4: 'Google', 6: 'WhatsApp', 8: 'YouTube', 99: 'None'}
cols17 = {1: 'S3_3_1', 2: 'S3_3_2', 3: 'S3_3_3', 4: 'S3_3_4', 6: 'S3_3_6', 8: 'S3_3_8', 99: 'S3_3_11'}
base17 = d17[[f'S3_3_{k}' for k in range(1, 12)]].notna().any(axis=1); W17 = w17[base17].sum()
d23, m23 = pyreadstat.read_sav('/home/claude/data/subtel/BBDD_Acceso_y_uso_Internet_v4.sav'); w23 = d23['POND_USO']
plat23 = {1: 'Facebook', 2: 'Twitter/X', 3: 'Instagram', 6: 'YouTube', 7: 'WhatsApp', 8: 'TikTok', 98: 'None'}
cols23 = {k: f'S3_3_{k}' for k in plat23}
base23 = d23[[f'S3_3_{k}' for k in [1,2,3,4,5,6,7,8,9,97,98]]].notna().any(axis=1); W23 = w23[base23].sum()
rows = []
for k, name in plat17.items():
    rows.append({'platform': name, 'year': 2017, 'pct': round(float(w17[base17 & d17[cols17[k]].notna()].sum() / W17 * 100), 1), 'n_base': int(base17.sum())})
for k, name in plat23.items():
    rows.append({'platform': name, 'year': 2023, 'pct': round(float(w23[base23 & (d23[cols23[k]] == 1)].sum() / W23 * 100), 1), 'n_base': int(base23.sum())})
plat = pd.DataFrame(rows); plat.to_csv(f'{OUT}/fig3_platforms_news_2017_2023.csv', index=False)
print(plat.pivot(index='platform', columns='year', values='pct'))

# ---------------- ELSOC trust 2016-2022 ----------------
wmap = {'01': 2016, '02': 2017, '03': 2018, '04': 2019, '05': 2021, '06': 2022}
items = {'c05_01': 'Government', 'c05_08': 'President', 'c05_07': 'Congress', 'c05_02': 'Political parties', 'c05_03': 'Carabineros',
         'c05_10': 'Armed Forces', 'c05_11': 'Bomberos', 'c05_12': 'Traditional media', 'c05_13': 'Municipality', 'c14_02': 'Informs about politics via media (often/very often)'}
_, metaE = pyreadstat.read_dta('/home/claude/data/elsoc/ELSOC_Wide_2016_2022_v1.00.dta', metadataonly=True)
cols = [c for c in metaE.column_names if any(c.startswith(s + '_w') for s in items) or c.startswith('ponderador02_w')]
E, _ = pyreadstat.read_dta('/home/claude/data/elsoc/ELSOC_Wide_2016_2022_v1.00.dta', usecols=cols)
rows = []
for s, name in items.items():
    for wv, yr in wmap.items():
        v = f'{s}_w{wv}'
        if v not in E: continue
        wt = E[f'ponderador02_w{wv}']; x = E[v]; m = x.between(1, 5) & wt.notna() & (wt > 0)
        rows.append({'item': name, 'year': yr, 'pct_high': round(float(((x[m] >= 4) * wt[m]).sum() / wt[m].sum() * 100), 1), 'n': int(m.sum())})
els = pd.DataFrame(rows); els.to_csv(f'{OUT}/fig2_elsoc_trust_2016_2022.csv', index=False)
print(els.pivot(index='item', columns='year', values='pct_high'))

# ---------------- TS3 table: sources and trust by age and education ----------------
T, mT = pyreadstat.read_sav('/home/claude/data/termometro/TS3/TS3.SAV'); wT = T['factor']
ageT = pd.cut(T['edad'], [17, 34, 59, 120], labels=['18-34', '35-59', '60+'])
edu = np.where(T['f1'].between(1, 9), 'Up to secondary', np.where(T['f1'].between(10, 14), 'Post-secondary', None))
edu = pd.Series(edu, index=T.index)
groups = [('All', T.index == T.index)] + [(f'Age {g}', (ageT == g).values) for g in ageT.cat.categories] + [(g, (edu == g).values) for g in ['Up to secondary', 'Post-secondary']]
src = {'d4__1': 'Television', 'd4__5': 'Social media', 'd4__3': 'Internet search', 'd4__2': 'Radio', 'd4__7': 'Family/friends', 'd4__4': 'Newspapers'}
trust = {'d115': 'Health workers', 'd116': 'Colegio Médico', 'd117': 'Carabineros/Armed Forces', 'd112': 'Mayors', 'd111': 'Health Minister', 'd113': 'President', 'd114': 'Congress'}
rows = []
for gname, m in groups:
    m = pd.Series(m, index=T.index)
    rec = {'group': gname, 'n': int(m.sum())}
    for v, name in src.items():
        p, _ = wshare(T.loc[m, v], wT[m]); rec[f'source: {name}'] = round(p, 1)
    for v, name in trust.items():
        x = T.loc[m, v]; mm = x.between(1, 5); rec[f'trust: {name}'] = round(float(((x[mm] >= 4) * wT[m][mm]).sum() / wT[m][mm].sum() * 100), 1)
    x = T.loc[m, 'd2']; mm = x.between(1, 5); rec['reaction insufficient (1+2)'] = round(float(((x[mm] <= 2) * wT[m][mm]).sum() / wT[m][mm].sum() * 100), 1)
    for v, name in {'d9__2': 'obstacle: people distrust authorities', 'd9__1': 'obstacle: people misinformed'}.items():
        p, _ = wshare(T.loc[m, v], wT[m]); rec[name] = round(p, 1)
    rows.append(rec)
ts3 = pd.DataFrame(rows); ts3.to_csv(f'{OUT}/table1_ts3_sources_trust.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30)
print(ts3.T)
