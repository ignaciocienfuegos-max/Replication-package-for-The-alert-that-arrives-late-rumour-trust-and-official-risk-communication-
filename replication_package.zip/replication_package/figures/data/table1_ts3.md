| | All | Age 18-34 | Age 35-59 | Age 60+ | Up to secondary | Post-secondary |
|---|---|---|---|---|---|---|
| n | 1,078 | 267 | 499 | 312 | 633 | 445 |
| source: Television | 70.5 | 51.4 | 75.4 | 90.3 | 80.1 | 60.0 |
| source: Social media | 39.4 | 53.9 | 42.0 | 11.9 | 34.7 | 44.4 |
| source: Internet search | 33.5 | 44.9 | 31.3 | 20.3 | 26.7 | 41.0 |
| source: Radio | 13.8 | 7.1 | 14.7 | 22.4 | 13.9 | 13.8 |
| source: Family/friends | 9.3 | 4.8 | 10.5 | 13.7 | 11.1 | 7.3 |
| source: Newspapers | 7.4 | 5.8 | 9.0 | 6.9 | 3.1 | 12.1 |
| trust: Health workers | 95.5 | 94.3 | 95.6 | 97.3 | 95.4 | 95.7 |
| trust: Colegio Médico | 76.6 | 74.1 | 75.8 | 82.1 | 78.2 | 74.9 |
| trust: Carabineros/Armed Forces | 51.7 | 29.2 | 55.1 | 79.7 | 61.6 | 40.9 |
| trust: Mayors | 47.0 | 33.9 | 46.4 | 68.6 | 48.3 | 45.6 |
| trust: Health Minister | 14.5 | 3.7 | 12.6 | 34.9 | 20.3 | 8.2 |
| trust: President | 14.4 | 6.8 | 12.4 | 30.2 | 19.8 | 8.4 |
| trust: Congress | 3.9 | 3.8 | 2.5 | 6.8 | 5.2 | 2.5 |
| reaction insufficient (1+2) | 76.8 | 87.9 | 76.4 | 60.2 | 68.8 | 85.5 |
| obstacle: people distrust authorities | 38.5 | 44.9 | 34.4 | 36.8 | 35.1 | 42.3 |
| obstacle: people misinformed | 18.7 | 29.7 | 12.7 | 13.8 | 13.2 | 24.8 |