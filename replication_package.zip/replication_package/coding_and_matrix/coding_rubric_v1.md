# Coding rubric v1 — official risk communication across the four Chilean cases

**Version:** 1.1, 3 September 2026 (v1.0 of 2 September piloted on the 2024 fire; v1.1 adds the changes forced by the 27F pass — a codable non-warning decision, a reception field separate from dispatch — plus the fifth specificity element, consistency against the monitoring record and Stage V sub-codes, and carries first passes for all four cases in §§6–9). Sources for each criterion are in the project PDFs: Reynolds & Seeger 2005 (CERC stages, Table 2), Seeger 2006 (ten best practices), Veil, Buehner & Palenchar 2011 (social-media adaptation; listening), Wendling et al. 2013 (OECD checklists, Tables 2–4), Mileti & Sorensen 1990 / Mileti & O'Brien 1992 (warning characteristics), Eckert et al. 2018 (rumour response), Peña y Lillo & Rosenberg 2024 (SCCT strategy and message orientation, for comparability with the existing COVID coding).

## 1. Unit of analysis

An **official communicative act**: any discrete message or decision by a State actor addressed to the public or to another agency that shapes what the public can know or do — alert declarations (temprana preventiva / amarilla / roja), SAE messages, posts on official social accounts, press statements and briefings, decrees and bandos, televised addresses, official corrections of rumours. One row per act. Inter-agency acts (CONAF → SENAPRED requests, EMCO emails) are coded too, with `audience = agency`, because the 2024 case turns on them.

Public-side events (media reports, rumour episodes, backchannel warnings, community coordination) are logged in the same timeline with `track = P` but coded with the shorter Section 4 scheme.

## 2. Variables per act

| Field | Values | Notes |
|---|---|---|
| `case` | 27F / COVID / FIRE24 / FLOOD26 | |
| `datetime` | ISO local time; `~` if approximate | Confidence flag: High / Medium / Low (as in the timeline) |
| `actor` | SENAPRED (ONEMI) / CONAF / SHOA / MINSAL / Delegación / Ministry (Interior, Defence) / President / Municipality / Armed Forces (JDN) / Carabineros / other | |
| `channel` | SAE cell broadcast / X post / other social (Instagram, Facebook, WhatsApp channel) / press conference / radio–TV statement / decree–bando / email–fax–radio to agency | Multi-channel acts get one row per channel |
| `audience` | public-general / public-sector-specific / agency | |
| `cerc_stage` | I precrisis / II initial event / III maintenance / IV resolution / V evaluation | Stage boundaries per case are set in §5 of the outline; for FIRE24: I = to 12:06 on 2 Feb; II = 12:06–00:30 on 3 Feb (first Cogrid nacional); III = 3–9 Feb; IV = 10 Feb–Mar 2024; V = Mar 2024 onward |
| `content_type` | warning–evacuation / status–situation / instruction–self-efficacy / reassurance / attribution–cause / correction–myth-busting / accountability–blame / recovery–aid / **non-warning decision** (v1.1: a decision not to warn, to downgrade or to cancel, with its stated evidential basis) | Multiple allowed |
| `specificity` (warning acts only) | 0–5: one point each for **hazard**, **location** (named sector), **action** (what to do), **time** (when/how long), **direction/route** (v1.1) | Mileti & Sorensen's specificity criterion; SAE's 90 characters make 5/5 rare; "no decía para dónde" was the dominant 2024 complaint |
| `consistency` | consistent / inconsistent with other official acts in the previous 2 h; **and** (v1.1) consistent / inconsistent with the monitoring record at the time | e.g., "no hay riesgo de viviendas" at 18:14 vs SAE at 18:23 → inconsistent; the 16:40 and 18:14 reassurances were consistent with each other but not with the 17:35–17:40 tower and helicopter reports |
| `reception` (v1.1) | documented / partial (n of N addressees; receipt confirmations) / none documented / not applicable | Coded separately from dispatch: 8 of 69 (SHOA 2010); 1 receipt confirmation in 47 (SAE 2024); no receipt data (SAE 2026) |
| `stage_v_subcode` (v1.1; Stage V acts only) | finding / sanction / reform / no-sanction closure | e.g., Cámara report = finding; Malfanti sentence 2014 = sanction; SAE decree 2012 = reform; Fiscalía closure 2025 (COVID) = no-sanction closure |
| `uncertainty_ack` | yes / no | Seeger practice 9 ("what we know at the present time") |
| `self_efficacy` | yes / no | Seeger practice 10: does it tell people what they can do? |
| `honesty_openness` | yes / no / n.a. | Seeger practice 5; retrospective: contradicted by later evidence? (e.g., the 18:39 logbook) |
| `listening` | yes / no | Veil et al.: does the act respond to public input (calls, reports, rumours)? |
| `orientation` | audience-oriented / sender-oriented | Peña y Lillo & Rosenberg 2024 |
| `scct_strategy` | instructing / adjusting / reinforcing (bolstering) | as in Peña y Lillo & Rosenberg 2024 |
| `rumour_response` | none / official denial / evidence-based correction / adoption of organic hashtag / referral to fact-checkers | Eckert et al. 2018 |
| `latency_ref` | link to the hazard event the act responds to | used to compute latencies |

## 3. Latency measures (per case)

- **L1 Hazard-to-alert:** hazard confirmed by an official monitoring source → first public warning for the affected sector.
- **L2 Dispatch-to-reception:** official dispatch → first documented reception (post timestamp, receipt log, testimony).
- **L3 Reassurance gap:** last official reassurance → first warning contradicting it (negative values mean no reassurance).
- **L4 Rumour-to-correction:** first documented rumour → first official correction.
- **L5 Event-to-evaluation:** event → first official evaluation document (commission report, audit, judicial finding).

## 4. Public-side scheme (track P)

`type` = backchannel warning / rumour–misinformation / self-correction by users / community coordination / media agenda; `channel` = WhatsApp / radio / X / Facebook–Instagram / TikTok / face-to-face; `verified_by` = users / media / fact-checker / authority / never; `source_confidence` as above.

## 5. Reliability

Two coders; 20% double-coded; Krippendorff's α reported per variable; disagreements on `cerc_stage` and `specificity` resolved by rule (boundary dates; specificity counted literally from the message text).

## 6. Pilot application — 2024 fire, selected acts (first pass)

| Time (2 Feb unless stated) | Actor / channel | Act | Stage | Content | Spec. | Consist. | Orient. | SCCT | Notes |
|---|---|---|---|---|---|---|---|---|---|
| 02:31 | SENAPRED / alert decl. | Alerta Roja Valparaíso (Las Docas) | I | status | – | – | audience | instructing | Time contested (02:31 vs 03:25) |
| 13:29 | CONAF / X | Alerta roja Las Tablas | II | status | – | consistent | audience | instructing | |
| 15:00 | SENAPRED / alert decl. | Alerta Roja provinces Valparaíso & Marga Marga | II | status | – | consistent | audience | instructing | Ignition→red alert ≈ 3 h |
| 16:35 / 16:40 | SENAPRED / SAE + X | Evacuate Quebrada Escobares, Fundo El Rincón (Villa Alemana) | II | warning | 3 (hazard implicit) | consistent | audience | instructing | Only SAE with receipt confirmation (16:46) |
| ~16:40–17:00 | Acting delegada / press | "de momento no hay riesgo de viviendas afectadas" | II | reassurance | – | inconsistent with 17:35–17:40 monitoring | sender | reinforcing | uncertainty_ack = no |
| 17:42 | Bomberos cmdr / WhatsApp (P) | "Se pasó para Viña y Quilpué" | II | backchannel warning | – | – | – | – | Precedes any SAE for Viña by ~55 min |
| 18:14 | Acting delegada / press | "no hay ningún tipo de riesgo por ahora de afectación de viviendas" | II | reassurance | – | inconsistent | sender | reinforcing | L3 = 9–23 min |
| 18:23–18:36 | CONAF→SENAPRED / SAE | First evacuation messages, Quilpué sectors | II | warning | 2–3 | consistent | audience | instructing | Four reported times; Cámara: "20 min after homes reached" |
| 18:37 / 18:41 | SENAPRED / SAE + X | Evacuate Villa Hermosa, Villa Dulce, Canal Beagle, El Olivar, Jardín Botánico | II | warning | 3 (no direction/route) | consistent | audience | instructing | L1 = 57–61 min; L2 = 4 min; "no decía para dónde" |
| 18:39 | CONAF / logbook (agency) | Entry claiming request for the Viña sectors | II→V | accountability | – | – | sender | reinforcing | PDI: written afterwards; honesty = no |
| 21:19 | SENAPRED / SAE + X | Evacuate Villa Rucán, Villa Arauco, Villa Independencia | II | warning | 3 | consistent | audience | instructing | Sector with most destroyed homes; earlier coverage unresolved |
| 21:49 | SENAPRED / bulletin | Monitoring bulletin: 16 SAE, ha, closures | II | status | – | consistent | audience | instructing | |
| ~23:30 | President / X | Estado de excepción announced; Cogrid advanced | II | status + instruction | – | consistent | audience | instructing/adjusting | |
| 3 Feb 00:30 | Interior Minister / briefing | Curfew 08–12; "no tenemos un número confirmado de víctimas" | II | instruction + status | – | consistent | audience | instructing | uncertainty_ack = yes |
| 3 Feb 12:45 | Interior Minister / briefing | Asks public not to post victim videos | III | instruction | – | – | audience | adjusting | listening = yes |
| 3 Feb 19:14 | President / TV address | 46 deaths; "Si le llega un mensaje para evacuar, no dude" | III | status + self-efficacy | – | consistent | audience | instructing | self_efficacy = yes |
| 3 Feb 23:11 | Interior Minister / briefing | Warns of fraudulent FIBE forms | III | correction | – | – | audience | instructing | rumour_response = official denial; L4 < 24 h |
| 4 Feb ~13:30 | President / briefing | Counts restricted to SML henceforth | III | status | – | consistent | audience | adjusting | uncertainty reduction by source rule |
| 4 Feb | Carabineros / Interior | Water-bottle arrest: "solo se trataba de agua"; "un malentendido" | III | correction | – | – | audience | instructing | L4 < 24 h |
| Oct 2024 → Jul 2026 | Cámara, Contraloría, PDI, Fiscalía | Evaluation documents | V | accountability | – | – | – | – | L5 = 8 months (Cámara) / 11 (Contraloría) / 30 (PDI, formalisation) |

**What the pilot shows about the rubric.** `specificity` needs a fifth element for **direction/route** (the dominant complaint in testimonies); `consistency` should be computed against the monitoring record as well as against other public acts (the 16:40 and 18:14 reassurances were consistent with each other but not with what CONAF's tower knew); Stage V acts need their own sub-codes (finding / sanction / reform). These go into v1.1 before coding 27F.

## 7. First pass — 27F, 27 February 2010 (case 1), selected acts

Stage boundaries for 27F: I precrisis = to 03:34; II initial event = 03:34 → ~12:00 on 27 Feb (first daylight tolls and the first Comité de Operaciones); III maintenance = 27 Feb noon → 5 Mar (identified-victims list, mourning); IV resolution = Mar–Dec 2010 (reconstruction plan, UN mission); V evaluation = Cámara commissions 2010/2012, criminal case 2012–2017, civil cases to 2025.

| Time (27 Feb unless stated) | Actor / channel | Act | Stage | Content | Spec. | Consist. | Orient. | SCCT | Notes |
|---|---|---|---|---|---|---|---|---|---|
| 03:46 | PTWC → SHOA / bulletin (agency) | Warning for Chile and Peru | II | warning | 3 | – | – | – | Reception by SHOA partly failed ("se cortó") |
| 03:51 | SHOA duty officer / VHF + e-mail (agency) | "Alerta de tsunami en curso"; dissemination ordered | II | warning | 2 | consistent with PTWC | – | – | ONEMI denies receiving it (contested) |
| 04:05 | SHOA / Genmercalli network (agency) | Written alert to ~70 addressees | II | warning | 3 (arrival times for 11 points) | consistent | – | – | 8 of 69 received (L2 failure) |
| 04:07–04:08 | SHOA → ONEMI / fax (agency) | "Alerta de tsunami" with arrival times | II | warning | 3 | consistent | – | – | Read by ONEMI as "alistamiento"; no public act followed |
| ~04:00–04:15 | Subsecretario Interior / decision at ONEMI | Decides against an evacuation alert | II | (non-)warning | – | inconsistent with the fax | sender | – | Basis: "epicentro en tierra"; honesty = n.a., listening = no |
| 04:41–04:56 | SHOA director / radio to ONEMI (agency) | Cancels the alert | II | cancellation | – | inconsistent with PTWC Bulletin 2 (04:45) and gauges | – | – | ≥ 32 deaths after this act; "un problema menos" |
| 05:01 | Intendente Biobío / Radio Bío-Bío | "no hay… ningún peligro de tsunami" | II | reassurance | – | inconsistent with the 04:07 fax and 04:20–04:40 Juan Fernández waves | sender | reinforcing | uncertainty_ack = no; public act #1 |
| ~05:20 | Intendente / Radio Bío-Bío | "el almirante me acaba de llamar… reiterar la calma" | II | reassurance | – | inconsistent | sender | reinforcing | "miles retornaron"; the admiral denies calling |
| 05:22 | ONEMI / statement | "no hay peligro de tsunami" | II | reassurance | – | inconsistent with its own 05:17 query to SHOA | sender | reinforcing | |
| 05:40–05:53 | President / TVN at ONEMI | First statement; tsunami risk denied or not mentioned (contested) | II | status + reassurance | – | inconsistent | sender | reinforcing | Wording contested across sources — code both versions |
| 06:50 | SHOA / "rectificación" | Acknowledges "oleajes de gran importancia" at Robinson Crusoe | II | correction | – | – | audience | adjusting | First official acknowledgement (L3 end, inside the system) |
| 06:55 | President / press | Confirms 16 dead and a "ola gigante" in Juan Fernández; "no habría riesgo de tsunami"; asks coastal residents to go to high ground if strong aftershocks | II | status + reassurance + instruction | 2 (action, no location/time) | internally inconsistent | mixed | instructing/reinforcing | The one self-efficacy element of the night |
| 08:30 | Interior Minister / press | First toll (78); "reiterating no tsunami warning" | II | status + reassurance | – | inconsistent | sender | reinforcing | uncertainty_ack = no |
| 09:00 | President / radio | "se descarta la alerta de tsunami" | II | reassurance | – | inconsistent (waves until ~06:40 already known) | sender | reinforcing | |
| 28 Feb | Defence Minister / press | "una repartición de la Armada cometió un error… fue un maremoto" | III | accountability–correction | – | consistent | audience | adjusting | Twitter confirmed truth: 124 affirm, 4 deny; honesty = yes |
| 28 Feb ~noon | President / decree DS 152–153 | Estado de excepción de catástrofe, Maule and Biobío; Jefes de la Defensa named | III | instruction + status | – | consistent | audience | instructing | ≈ 32 h after the shock |
| 28 Feb 21:00 | Jefe de la Defensa / bando | Curfew Concepción 21:00–06:00 | III | instruction | 3 | consistent | audience | instructing | |
| 1 Mar | Carabineros / press | Santiago looting rumours "descartados"; 11 of 16 attacks frustrated | III | correction | – | – | audience | instructing | rumour_response = official denial; L4 ≈ 24–36 h |
| 3–4 Mar | Carabineros loudspeakers vs ONEMI | "Alerta de tsunami" call to high ground → ONEMI denies | III | warning then correction | 2 | inconsistent between agencies | audience | instructing | Intra-State contradiction; panic on coastal roads |
| 5 Mar | Subsecretario Interior / press | Switch to a list of identified victims (279) replacing ~800 estimate | III | status | – | consistent | audience | adjusting | Uncertainty reduction by source rule (cf. 4 Feb 2024) |
| Mar 2010 → 2025 | Cámara, UN mission, Fiscalía, courts | Evaluation documents | V | accountability | – | – | – | – | L5: 12 days (commission), 8 months (UN), 26 months (formalisation), 6 years (suspension), 7.5 years (dismissal); no convictions |

**What the 27F pass adds to the rubric.** Two codes are needed that the 2024 pilot did not force: (a) a **non-warning decision** as a codable act (the 04:00–04:15 decision not to evacuate; the 04:41–04:56 cancellation) with its evidential basis recorded; (b) **inter-agency reception** as a separate field from dispatch (8 of 69; a fax after five attempts; a VHF message one side says it never heard), because in both 2010 and 2024 the failure sat between agencies before it reached the public. Both are in v1.1 (§2).

## 8. First pass — COVID-19 (case 2), selected episodes

Stage boundaries: I precrisis = 5 Feb (Decreto 4) → 2 Mar 2020; II initial event = 3 Mar → 26 Mar 2020 (first quarantine); III maintenance = Apr 2020 → Sep 2021; IV resolution = 24 Dec 2020 (first doses) → 30 Sep 2021, overlapping III; V evaluation = 12 Jun 2020 (Senate hearing) → 29 May 2025 (Fiscalía closure). Episodes are coded at the level of the day; the "monitoring record" for consistency is the epidemiological series (cases, ICU occupancy, DEIS deaths) on the day of the act. Full evidence base: `claude/timeline-covid19-chile.md`.

| Date (2020 unless stated) | Actor / channel | Act | Stage | Content | Consist. (acts / monitoring) | Uncert. ack. | Orient. | SCCT | Notes |
|---|---|---|---|---|---|---|---|---|---|
| 3 Mar 16:30 | Minister / press point at Talca hospital, live TV | First case announced in person, 4 h 15 after confirmation | II | status | consistent / consistent | yes | audience | instructing | L1 = 4 h 15; sender chosen by the President ("verify in person") |
| 15 Mar | President / MINEDUC | School closure after mayors' pressure, against the Consejo Asesor | II | instruction | inconsistent with the Consejo's 14–15 Mar advice / consistent | no | audience | instructing | listening = yes (to mayors) |
| 18 Mar | President / DS 104 | Estado de excepción constitucional de catástrofe, 90 days | II | instruction + status | consistent / consistent | no | audience | instructing | Renewed five times to 30 Sep 2021 |
| 20–21 Mar | Minister / 24 Horas TV | "¿Qué pasa si muta y se pone buena persona?" — against a total lockdown | II | reassurance | inconsistent with mayors' demand / n.a. (no monitoring basis) | no | sender | reinforcing | honesty_openness = n.a.; the quoted wording, not the paraphrase |
| 20 Mar | Clínica Alemana, Sochepi / Twitter, press | Denials of fake WhatsApp audios and a fake cacerolazo call | II | correction | – | – | audience | instructing | rumour_response = official denial (by the named institutions, not MINSAL); L4 ≤ 1 day |
| 3 Apr | President / photograph at Plaza Baquedano | Non-verbal act during quarantine; La Moneda "lamenta si se malinterpretó" | III | (reassurance by conduct) | inconsistent with the quarantine instruction / – | – | sender | reinforcing (bolstering) | honesty_openness: "no cometí ningún delito" (12 Apr) |
| 9 → 27 Apr | Minister, Subsecretaria / daily briefing | "Carnet COVID": "no se va a enfermar de nuevo" (9 Apr) → "probabilidad muy alta" (21 Apr) → withdrawn (27 Apr) | III | instruction → reassurance → correction | inconsistent with WHO 19/24 Apr / – | no → yes | sender | reinforcing → adjusting | L3 (claim → retreat) = 18 days; uncertainty acknowledged only after external contradiction |
| 17–24 Apr | President, Minister / briefings, radio | "Nueva normalidad" / Plan Retorno Seguro ("va a llegar con la primavera"; malls, officials back in May) | III | reassurance + instruction | inconsistent with the case trend / inconsistent | no | sender | reinforcing | 4–5 May renamed "Batalla de Santiago" — L3 = 11–18 days |
| 16–17 Apr | 50+ mayors / open letter | Demand for comuna-level data and an end to "secretismo" (P track) | III | – | – | – | – | – | Central–local information asymmetry; listening = no (until data shared) |
| 6 May | Minister / daily briefing | Installed capacity "capaz de tolerar con largueza un incremento… dramático"; "tranquilidad" | III | reassurance | consistent with 17–24 Apr acts / **inconsistent** with >1,000 cases/day, 72% ICU, 95% Sur Oriente | no | sender | reinforcing | L3 = 19 days to 25 May; the chronic-case analogue of 05:20 (2010) and 18:14 (2024) |
| 13–15 May | Minister / daily briefing | Cuarentena total for Greater Santiago | III | instruction | consistent / consistent | no | audience | instructing | Announced Wed, effective Fri 22:00 |
| 25–26 May | President, Minister / press | "Estamos muy cerca del límite"; "dilema de la última cama"; projections "castillo de naipes" (26 May) | III | status + uncertainty | consistent / consistent | **yes** | audience | adjusting | First adjusting turn of the case |
| 29 May | Minister / briefing, minsal.cl | "Garantiza transparencia de reportes"; announces Contraloría audit | III | reassurance + accountability | inconsistent with internal e-mails (CIPER 2023) / inconsistent with DEIS series | no | sender | reinforcing | honesty_openness = no (retrospective: two counts known internally by May) |
| 13 Jun | CIPER / online 04:07 (P) → President / La Moneda (O) | Two-count revelation → Minister's resignation the same afternoon | III→V | accountability | – | – | – | – | L4 (revelation → institutional response) < 1 day; sanction = resignation, not a finding |
| 16 Jun | Minister Paris / Twitter | "Hibernación" WhatsApp chain "es FALSO", "malintencionada" | III | correction | – | – | audience | instructing | rumour_response = official denial; L4 ≤ 1 day |
| 20 Jun | MINSAL (Araos, Paris) / briefing | Two death series published side by side: "metodologías distintas… no sumar" | III | status + correction | consistent / consistent | yes | audience | adjusting | Uncertainty reduction by source rule (cf. 5 Mar 2010; 4 Feb 2024) |
| 19 Jul | President, Minister, Subsecretaria / La Moneda | Plan Paso a Paso: five steps by comuna, "escuchando siempre a la comunidad" | III/IV | instruction | consistent / consistent | yes | audience | instructing/adjusting | listening claimed; decisions still central (Mon/Thu announcements, Thu/Sat 05:00) |
| 16 Aug | Minister / briefing | Televised briefing cut to three days a week; written daily report continues | III | status | – | – | audience | adjusting | Channel change, not content |
| 16 Dec | @ministeriosalud / Twitter | Fake Emol-style "RM returns to quarantine" denied the same day; "informarse a través de los canales oficiales" | III | correction | – | – | audience | instructing | rumour_response = official denial + referral to official channels; L4 ≤ 1 day |
| 24 Dec 2020 – 3 Feb 2021 | President, Minister / Hospital Metropolitano; #YoMeVacuno | First doses; mass campaign | IV | instruction + recovery | consistent / consistent | – | audience | instructing | Campaign contract judged "purely informative" (Apr 2021) |
| 25–27 Mar 2021 | Minister / briefing | Whole RM back to quarantine; 198 comunas, ~16 M people | III | instruction + status | consistent / consistent | yes ("preocupante aumento") | audience | instructing | Second wave |
| 12 Jun 2020 → 29 May 2025 | Senate, Contraloría, Cámara, CIPER, Fiscalía | Evaluation documents | V | accountability | – | – | – | – | Sub-codes: finding (Senate 12 Jun 2020; Contraloría 25 Aug 2020; Cámara 7 Jan 2021 — "manejo comunicacional errático y temerario"); sanction: none (acusación rejected 13 Oct 2020; Fiscalía closure 29 May 2025 = no-sanction closure); reform: Consejo Asesor Externo 22 Mar 2022. L5 = 101 days (Senate), 175 days (Contraloría), 310 days (Cámara Sala), 5 y 3 m (Fiscalía) |

**What the COVID pass shows.** Reinforcing/sender-oriented acts cluster in April–May 2020 and turn to adjusting only after external contradiction (WHO, the case curve, CIPER); every documented rumour correction that MINSAL made was a denial on Twitter, and the fastest corrections came from the institutions the rumour named, not from the ministry; the one structural uncertainty-reduction act (20 June) came after the credibility loss. The consistency-against-monitoring field does the analytical work here exactly as in the acute cases.

## 9. First pass — Norte Grande floods, 16–19 August 2026 (case 4), selected acts

Stage boundaries: I precrisis = to 16 Aug (forecasts, ATP and alertas amarillas, evacuation maps); II initial event = 17 Aug morning (first preventive SAE) → 19 Aug 13:21 (Iquique downgraded to amarilla); III maintenance = 19 Aug → 1 Sep (Tocopilla/Taltal downgraded); IV resolution = from 21 Aug (DS 134, Fondo de Reconstrucción 31 Aug); V evaluation = none at 3 Sep. Times CLT (UTC−4). Full evidence base: `claude/timeline-2026-norte-grande-floods.md`.

| Time | Actor / channel | Act | Stage | Content | Spec. | Consist. (acts / monitoring) | Reception | Orient. | SCCT | Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| 14 Aug 00:28 | DMC/SENAPRED via press | Public forecast of the second system, three days ahead | I | status | – | consistent / consistent | – | audience | instructing | L1 (forecast level) = 3–4 days |
| 15 Aug 09:27 | DMC / forecast | Antofagasta coast 4–7 mm/day | I | status | – | – / **under-forecast** (37.1 mm fell) | – | audience | instructing | Hazard-track error, not a communication act |
| 15 Aug 23:02; 16 Aug 16:26; 16 Aug evening | SENAPRED regional / alert notices | Alertas amarillas: Iquique, Alto Hospicio, Huara; Arica region; Antofagasta, Taltal, Mejillones, Tocopilla (with SERNAGEOMIN "alta") | I | warning | 3 (hazard, location, time; no action) | consistent / consistent | not documented | audience | instructing | Classes suspended Mon; evacuation maps re-published (Tarapacá) |
| 17 Aug morning (<11:18) | SENAPRED / SAE | Early evacuation after the overnight quebrada activations: Huella Tres Puntas, Colón; Pacífico Norte, Tres Marías (Tocopilla); shelters named (classed by SENAPRED as evacuation reinforcement; the day's four "preventive" messages were in Atacama and Coquimbo) | II | warning | 4 (hazard implicit; location, action, shelter as direction) | consistent / consistent | not documented; ~2,000 evacuated | audience | instructing | **Early use of SAE** — a day before the main mudflows; precedes the DMC alarma |
| 17 Aug 13:24 | DMC / Alarma AAA8/2026 | 15–25 mm Tocopilla–Taltal for 18 Aug | II | warning | 3 | consistent / under-forecast | – | audience | instructing | ~24 h before the peak |
| 17 Aug ~21:30 | SENAPRED national (Cebrián) + Minister / balance | 1 dead; 8 SAE (4 evacuation, 4 preventive); "El evento no ha terminado" | II | status + warning | – | consistent / consistent | – | audience | instructing | uncertainty_ack = yes |
| 18 Aug morning | SENAPRED Tarapacá (instrument not found) | Alert downgrade in Iquique ~3 h before the SAE and alerta roja | II | **non-warning decision** | – | inconsistent with the 17 Aug alarma / – | – | – | – | Mayor: "se genera una confusión"; C.8 in the timeline |
| 18 Aug 12:55–13:07 | SENAPRED / SAE | "Por activación de quebradas se solicita EVACUAR sectores Almirante Riveros y O'Higgins" (Tocopilla) | II | warning | 3 (hazard, location, action; no time/route) | consistent / concurrent with the mudflow (~12:30–13:05) | not documented | audience | instructing | L1 (impact level) ≈ 0 to −30 min |
| 18 Aug 13:09–13:18 | SENAPRED Antofagasta / alert notice | Alerta roja Antofagasta, Taltal, Mejillones, Tocopilla | II | warning | 3 | consistent / **after** the aluvión | – | audience | instructing | Reactive escalation; extended to the region 15:11 |
| 18 Aug 15:31 | SENAPRED Tarapacá / SAE | Evacuate Caletas San Marcos, Río Seco (Iquique) | II | warning | 3 | consistent / consistent | not documented; "se logró advertir y evacuar oportunamente" (mayor) | audience | instructing | Two hours before the Iquique alerta roja |
| 18 Aug ~15:40 → 17:50 | Alcaldesa Tocopilla (P/O) → Subsecretario 16:12 → Carabineros 17:50 | Three "missing" → "no hay denuncias formalizadas" → "era un problema de comunicación… fueron encontradas" | II | status → correction | – | – | – | audience | adjusting → instructing | L4 = 2 h 10; the correction came from Carabineros, not SENAPRED |
| 18 Aug ~16:00 | President / X | Estado de excepción de catástrofe for the province of Tocopilla; JDN to be named | II | instruction + status | – | consistent / consistent | – | audience | instructing | Decree number and JDN never published (gap) |
| 18 Aug 16:12–16:17 | Subsecretario Interior / press | "Lo más importante… es la transmisión de riesgo para que las personas evacúen a través de la alerta SAE"; horizontal evacuation explained | II | instruction–self-efficacy | consistent / consistent | – | audience | instructing | self_efficacy = yes |
| 18 Aug 17:28–18:14 | DMC meteorologist / Cooperativa | "La máxima intensidad… ya pasó"; headline "lo más intenso… ya pasó" | II | reassurance (hazard track) | inconsistent with SAE 19:10–22:08 / inconsistent with continuing activations | no | sender | reinforcing | L3 = 56 min (to SAE 19:10); differs from 2010/2024: warnings continued regardless |
| 18 Aug 18:18 | Subsecretario Interior / press | Antofagasta's pools "secas y con capacidad" | II | reassurance | inconsistent with SAE Coloso 19:58, Roca Roja 21:40 / – | no | sender | reinforcing | L3 = 1 h 40 |
| 18 Aug 19:10–22:08 | SENAPRED / SAE ×5 | Tocopilla second wave of sectors; Coloso; Miramar; Roca Roja; Río Salado ("EVITAR acercarse a la ribera") | II | warning | 3 (Río Salado: warning without evacuation) | consistent / consistent | not documented | audience | instructing | All reactive ("por activación de quebradas") |
| 18 Aug 21:11–21:20 | SENAPRED national / balance | 64 damnificados, 521 albergados, 3 injured; "13 mensajes SAE"; "El evento no ha terminado"; telecoms "mostly functional" | II | status | consistent / consistent | – | audience | instructing | uncertainty_ack = yes; SAE count contradicted (13 / 17 / ≥21) |
| 18 Aug night | Seremi de Energía Tarapacá / Radio Paulina | Rejects WhatsApp claims of grid collapse dependent on the Tocopilla plant | II | correction | – | – | – | audience | instructing | rumour_response = official denial; L4 = hours |
| 19 Aug 13:21 | SENAPRED Tarapacá / notice | Iquique province and Huara downgraded to amarilla | III | non-warning decision (downgrade) | – | consistent / consistent (aviso cancelled) | – | audience | instructing | |
| 19 Aug 13:34 | Mayor of Iquique / Radio Paulina (P/O) | "Se genera una confusión en las personas"; municipalities "la primera reacción" | III/V | accountability | – | – | – | – | – | First evaluative act, municipal |
| 19 Aug 15:36–21:08 | President / Tocopilla, Iquique | "evaluación positiva de las obras"; "plan maestro"; refuses zona de catástrofe for Alto Hospicio ("no queremos elevar las expectativas"); "los recursos son escasos" | III | status + recovery | consistent / – | yes | mixed | adjusting/reinforcing | Expectation management as a recovery-stage act |
| 19 Aug 16:11 | Mala Espina / fact-check (P) | Tocopilla video passed off as Peruvian floods with fake presidential attribution: "engañoso" | III | correction (P) | – | – | – | – | – | verified_by = fact-checker; L4 = 2 days |
| 21 Aug | Ministerio del Interior / DS 134 | Three regions zonas afectadas por catástrofe (Ley 16.282) | IV | recovery–aid | consistent / consistent | – | audience | instructing | Regional press: a reversal of the 19 Aug refusal |
| 20–26 Aug | DOH, Subsecretario, President vs alcaldesa, councillor; mayors | "Las obras funcionaron / salvaron vidas" vs "la mitad de las obras" / "No alcanzó la plata"; "la ciudad no está preparada" | V (informal) | accountability | – | – | – | mixed | reinforcing vs – | No formal evaluation document at 3 Sep; L5 undefined |

**What the 2026 pass shows.** The alert ladder worked at the forecast level (amarilla two days ahead, early SAE a day before the main mudflows, alarma twenty-four hours ahead) and failed at the impact level (roja after the mudflow; every day-two SAE reactive); the only reassurance came from the hazard track and did not suppress warnings; reception is undocumented rather than documented as failed; the first evaluative statements were municipal. Two rubric notes: (a) `reception = not documented` must be distinguished from `none` — in 2026 nobody reported a missing message, which is not the same as the 2024 finding that messages were not received; (b) a downgrade is a non-warning decision and needs the instrument recorded (here it could not be found), because the public reads the ladder as one signal.
